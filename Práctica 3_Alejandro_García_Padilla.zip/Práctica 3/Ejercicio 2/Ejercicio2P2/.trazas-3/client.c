#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/sem.h>
#include <ctype.h>


#define CLAVE 0x79295875L
#define TAM 1024
#define PERMISIONS 0666

int recid;
char sec1[24];
char sec2[24];
char sec8[24];
char sec10[24];

void espera(int *ejercicio);
void ejercicio1();
void ejercicio2();
void ejercicio3();
void ejercicio4();
void ejercicio5();
void ejercicio6();
void ejercicio7();

typedef union semun {
    int val;    /* Value for SETVAL */
    struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
    unsigned short  *array;  /* Array for GETALL, SETALL */
    struct seminfo  *__buf;  /* Buffer for IPC_INFO
                                           (Linux-specific) */
 }SEMUN;
 
/*Definimos las operaciones sobre semáforos*/
struct sembuf mutex_down = {0,-1, 0};
struct sembuf mutex_up = {0, 1, 0};
struct sembuf synch_down = {1,-1, 0};
struct sembuf synch_up = {1, 1, 0};
struct sembuf down_duo [2]={{0,-1, 0},{1,-1, 0}};
struct sembuf up_duo [2]={{0,1, 0},{1,1, 0}};

int main(int argc, char** argv) {
    int ejercicio = 1;
    espera(&ejercicio);
    ejercicio1();
    espera(&ejercicio);
    ejercicio2();
    espera(&ejercicio);
    ejercicio3();
    espera(&ejercicio);
    ejercicio4();
    espera(&ejercicio);
    ejercicio5();
    espera(&ejercicio);
    ejercicio6();
    espera(&ejercicio);
    ejercicio7();
    return (EXIT_SUCCESS);
}

void espera(int *ejercicio){ /*Será puntero para poder modificarla*/
    printf("Pulsa tecla para ejecutar ejercicio %d :\n", *ejercicio);
    __fpurge(stdin);
    getchar();
    (*ejercicio)++; 
}


void ejercicio1(){
    char* mem;
    int offset;
    int secret1;
    int recid = shmget(CLAVE, TAM, PERMISIONS); //Ya la ha creado el monitor
    mem = (char*) shmat(recid, NULL, 0);
    if(mem == (char*)-1){
        printf("ERROR GETTING POINTER\n");
        exit(EXIT_SUCCESS); 
    }
    secret1 = *(int*) mem;
    sprintf(sec1,"<%d>",secret1); /*Para meter el secreto 3*/
    offset = *(int*)(mem + sizeof(int));
    strcpy(sec2, mem +offset);
    printf("El secreto 1 es == %s\n", sec1);
    printf("El secreto 2 es == %s\n", sec2);
    sleep(3);
    shmdt(mem); //Nos desenganchamos de memoria
    
}

void ejercicio2(){
    char* mem;
    int posoff;
    int recid = shmget(CLAVE, TAM, IPC_CREAT|PERMISIONS);
    //sleep(2);
    mem = (char*) shmat(recid, NULL, 0);
    if(mem == (char*)-1){
        printf("ERROR GETTING POINTER\n");
        exit(EXIT_SUCCESS); 
    }
    strcpy(mem, sec2);
    sscanf(sec2,"<%d>", &posoff);
    strcpy(mem + 16 + posoff, sec1);
    sleep(2);
    shmdt(mem);
    printf("EJERCICIO 2.... ENDED OK\n");
}

void ejercicio3(){
    int semid;
    SEMUN arg;
    semid = semget(CLAVE, 1, IPC_CREAT|PERMISIONS);
    arg.val = 875;
    if(semctl(semid,0,SETVAL,arg)== -1){
        printf("ERROR ESTABLISHING MUTEX VALUE\n");
        exit(EXIT_SUCCESS); 
    }
    printf("Semaforo inicializado\n");
    printf("EJERCICIO 3.... ENDED OK\n");
}

void ejercicio4(){
    int semid;
    SEMUN arg;
    semid = semget(CLAVE, 2, IPC_CREAT|PERMISIONS);
    arg.val = 1;
    if(semctl(semid,0,SETVAL,arg)== -1){
        printf("ERROR ESTABLISHING MUTEX VALUE\n");
        exit(EXIT_SUCCESS); 
    }
    printf("Semaforo 1 inicializado\n");
    
    arg.val = 2;
    if(semctl(semid,1,SETVAL,arg)== -1){
        printf("ERROR ESTABLISHING MUTEX VALUE\n");
        exit(EXIT_SUCCESS); 
    }
    printf("Semaforo 2 inicializado\n");
    printf("EJERCICIO 4.... ENDED OK\n");
}

void ejercicio5(){
    int semid;
    int secret8;
    int aux;
    semid = semget(CLAVE,1,PERMISIONS);//Obtenemos el id del semáforo
    int recid = shmget(CLAVE, TAM, PERMISIONS);//Obtenemos el identificador de la zona de memoria compartida
    char* mem = (char*) shmat(recid, NULL, 0);
    if(mem == (char*)-1){
        printf("Error obteniendo puntero a zona de memoria compartida");
        exit(EXIT_SUCCESS);
    }
    if(semop(semid, &mutex_down, 1)==-1){ //Hacemos down al semáforo
        printf("Error operando sobre el semáforo");
        exit(EXIT_SUCCESS);
    }
    
    secret8 = *(int*)mem; //Obtenemos el entero
    sprintf(sec8,"<%d>",secret8);
    printf("El secreto 8 es = %s\n", sec8);
    aux = (-1)*secret8; //Le cambiamos el signo;
    *(int*)mem = aux; //Reescribimos en dicha posición;
    sleep(3);
    
    if(semop(semid, &mutex_up, 1)==-1){ //Hacemos up al semáforo permitiendo acceso del monitor
        printf("Error operando sobre el semáforo");
        exit(EXIT_SUCCESS);
    }
    
    printf("EJERCICIO 5 ENDED... CLAVES 8 Y 9 LOGRADAS\n");
    
}

void ejercicio6(){
    
    int semid;
    int secret10;
    int aux;
    semid = semget(CLAVE,2,PERMISIONS);//Obtenemos el id del semáforo
    int recid = shmget(CLAVE, TAM, PERMISIONS);//Obtenemos el identificador de la zona de memoria compartida
    char* mem = (char*) shmat(recid, NULL, 0);
    if(mem == (char*)-1){
        printf("Error obteniendo puntero a zona de memoria compartida");
        exit(EXIT_SUCCESS);
    }
    if(semop(semid, down_duo, 2)==-1){ //Hacemos down al semáforo
        printf("Error operando sobre el semáforo doble");
        exit(EXIT_SUCCESS);
    }
    
    secret10 = *(int*)mem; //Obtenemos el entero
    sprintf(sec10,"<%d>",secret10);
    printf("El secreto 8 es = %s\n", sec10);
    aux = (-1)*secret10; //Le cambiamos el signo;
    *(int*)mem = aux; //Reescribimos en dicha posición;
    sleep(3);
    
    if(semop(semid, up_duo, 2)==-1){ //Hacemos up al semáforo permitiendo acceso del monitor
        printf("Error operando sobre el semáforo synch_1");
        exit(EXIT_SUCCESS);
    }
    
    
    printf("EJERCICIO 6 ENDED... CLAVES 10 Y 11 LOGRADAS\n");
    
}

void ejercicio7(){
    int semid;
    semid = semget(CLAVE, 1, IPC_CREAT|PERMISIONS);
    recid = shmget(CLAVE, TAM, PERMISIONS);
    if(semop(semid, &mutex_down, 1)==-1){ //Hacemos down al semáforo --> Si es distinto de 1 se bloqueará el proceso
        printf("Error operando sobre el semáforo");
        exit(EXIT_SUCCESS);
    }
    shmctl(recid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID, NULL);
            
    printf("EJERCICIO 7 ENDED... CLAVE 12 LOGRADA\n");
}

