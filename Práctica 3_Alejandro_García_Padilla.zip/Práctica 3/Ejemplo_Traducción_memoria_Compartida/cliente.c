/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   cliente.c
 * Author: alex
 *
 * Created on 18 de marzo de 2024, 9:08
 */

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>



#define CLAVE 0x79295875L
#define TAM 1024
#define PERMISIONS 0666

void signalhandler1();

/*
 * 
 */
int main(int argc, char** argv) {
    
    /*Variables que permitiran asociar la zona de memoria compartida y obtener el identificador*/
    char* mem; 
    int recid; /*Identificador de recurso*/
    
    /*Declaramos la espera de una señal que será la que despierte al cliente una vez el server haya traducido*/
    signal(SIGUSR1, signalhandler1);
    
    /*Obtenemos el identificador de zona, creando esta*/
    recid = shmget(CLAVE,TAM, IPC_CREAT|PERMISIONS);
    
    /*Obtenemos el puntero al inicio de la zona de memoria*/
    mem = (char*) shmat(recid, NULL, 0);
    
    /*Comprobamos que el valor es correcto*/
    if(mem == (char*) -1){
        printf("THIS IS AN ERROR MATE\n");
        exit(EXIT_SUCCESS);
    }
    
    else{
        /*Para que el server nos pueda mandar la señal tendremos que comunicarle nuestro pid*/
        *(pid_t*) mem = getpid(); /*puntero de delante --> indica que es el contenido de la dirección.  
                                   * Lo otro es casting de tipo char* a tipo pid_t* */       
        printf("Introduce el texto que deseas traducir: \n");
        fgets(mem + sizeof(pid_t), TAM - sizeof(pid_t), stdin); /*Dirección comienzo, tamaño maximo*/
        
        /*Quitamos el \n del final*/
        mem[sizeof(pid_t) + strlen(mem + sizeof(pid_t))-1]=='\0';
        
        /*Nos pausamos en espera de la señal*/
        pause();
        /*Mostramos el contenido recibido en mayúsculas*/
        printf("El texto recibido a sido: %s \n", mem + 256); /*El server escribe 256 posiciones tras el comienzo de la zona*/
    }
    
    /*Desasociamos la memoria compartida y eliminamos dicha zona*/
    shmdt(mem);
    /*shmctl(recid, IPC_RMID,NULL);*/
    
    return (EXIT_SUCCESS);
}

void signalhandler1(){
    int i = 0;
    printf("CORRECT ==> SIGNAL RECEIVED FROM SERVER LOADING TRANSLATION ");
    for(i=0; i<10; i++){
        printf("#");
    }
    printf("\n");
}