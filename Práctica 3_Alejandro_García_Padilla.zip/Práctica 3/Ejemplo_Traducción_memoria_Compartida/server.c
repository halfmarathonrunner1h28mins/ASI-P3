/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   server.c
 * Author: alex
 *
 * Created on 18 de marzo de 2024, 9:09
 */

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>


#define CLAVE 0x79295875L
#define TAM 1024
#define PERMISIONS 0666
/*
 * 
 */
void toMayus(char* str);

int main(int argc, char** argv) {
    
    char* mem; /*Puntero que rellenaremos con la primera posición de la zona de memoria compartida*/
    int recid;
    pid_t client_pid;
    
    recid = shmget(CLAVE, TAM, PERMISIONS); /*Sin flag IPC_CREAT porque el recurso ya lo ha creado el cliente*/
    
    if(recid == -1){
        printf("Error en la obtención del identificador de recurso\n");
        exit(EXIT_SUCCESS); /*No ponemos else --> estamos matando aquí al proceso*/
    }
    
    mem = (char*)shmat(recid, NULL, 0); /*puntero a inicio de zona de memoria*/
    if(mem = (char*)-1){
        printf("Error en la obtención del puntero\n");
        exit(EXIT_SUCCESS); /*No ponemos else --> estamos matando aquí al proceso*/
    }
    client_pid =*(pid_t*)mem; /*Obtenemos el pid del cliente indicado que el contenido de la variable sea lo que haya dentro de mem previo casting*/
    toMayus(mem + sizeof(pid_t)); /*Pasamos a mayususculas en texto del espacio de memoria*/
    strcpy(mem + 256, mem + sizeof(pid_t));/*Copiamos el mensaje en mayúsculas a partir de la posición 256*/
    if((mem + sizeof(pid_t))!= NULL){
        kill(client_pid, SIGUSR1);/*Mando la señal que despierte al cliente*/
    }
    shmdt(mem);
    
    return (EXIT_SUCCESS);
}

void toMayus(char* str){
    
    while(*str){
        *str = toupper((unsigned char)*str); /*Contenido de str a mayúsculas*/
        str ++; /*Aumentamos la direccion*/
    }
    
}

