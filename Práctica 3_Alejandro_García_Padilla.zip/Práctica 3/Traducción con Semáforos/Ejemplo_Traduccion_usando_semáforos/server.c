/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   server.c
 * Author: alex
 *
 * Created on 25 de marzo de 2024, 9:03
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <string.h>
#include <ctype.h>


#define CLAVE 0x79295875L
#define TAM 1024
#define PERMISIONS 0666

void toMayus(char *str);

/*Declarar las estructuras*/
struct sembuf mutex_down = {0,-1,0};
struct sembuf mutex_up = {0,1,0};
struct sembuf sync_down = {1,-1,0};
struct sembuf sync_up = {1,1,0};

typedef union semun {
    int val;    /* Value for SETVAL */
    struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
    unsigned short  *array;  /* Array for GETALL, SETALL */
    struct seminfo  *__buf;  /* Buffer for IPC_INFO
                                           (Linux-specific) */
 }SEMUN;

int main(int argc, char** argv) {
    
    char *mem;
    int recid;
    int semid;
    SEMUN arg;
    
    /*1. Acceso a la zona de memoria compartida*/
    recid = shmget(CLAVE, TAM, PERMISIONS);
    if(recid == -1){
        printf("Error zona compartida de memoria\n");
        exit(EXIT_SUCCESS);
    }
    
    /*2. Obtener el puntero a dicha zona de memoria compartida*/
    mem = (char *)shmat(recid,NULL, 0);
    if(mem == (char *)-1){
        printf("Error attching");
        exit(EXIT_SUCCESS);
    }
    
    /*3. Vamos a acceder a la zona de memoria compartida --> Obtener acceso a los semaforos --> Down a MUTEX*/
     semid = semget(CLAVE, 2, PERMISIONS);
     if(semop(semid, &mutex_down, 1)== -1){
         printf("Error haciendo down a mutex");
         exit(EXIT_SUCCESS);
     }
     toMayus(mem);
     strcpy(mem+256, mem);
     
     /*4.Salimos de la zona de conflicto, up a mutex*/
     if(semop(semid, &mutex_up, 1)==-1){
         printf("Error haciendo up a mutex");
         exit(EXIT_SUCCESS);
     }
     
     /*5. Desbloqueamos el otro proceso con un up a sync*/
     if(semop(semid, &sync_up, 1) == -1){
         printf("Error haciendo up a sync");
         exit(EXIT_SUCCESS);
     }
    
     printf("BYE BYE\n");
     exit(EXIT_SUCCESS);

    return (EXIT_SUCCESS);
}

void toMayus(char *str){
    while(*str){
        *str = toupper((unsigned char)*str);
        str++;
    }
}



