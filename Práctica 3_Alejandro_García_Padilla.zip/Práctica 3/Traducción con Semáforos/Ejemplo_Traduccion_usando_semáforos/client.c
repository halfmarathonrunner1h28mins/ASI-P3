/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   client.c
 * Author: alex
 *
 * Created on 25 de marzo de 2024, 9:02
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <string.h>
#include <ctype.h>


#define CLAVE 0x79295875L
#define TAM 1024
#define PERMISIONS 0666

/*Declarar las estructuras*/
struct sembuf mutex_down = {0,-1,0};
struct sembuf mutex_up = {0,1,0};
struct sembuf sync_down = {1,-1,0};
struct sembuf sync_up = {1,1,0};

typedef union semun {
    int val;    /* Value for SETVAL */
    struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
    unsigned short  *array;  /* Array for GETALL, SETALL */
    struct seminfo  *__buf;  /* Buffer for IPC_INFO
                                           (Linux-specific) */
 }SEMUN;


int main(int argc, char** argv) {
    
    char *mem;
    int recid;
    int semid;
    SEMUN arg;
    
    /*1. Creación de la zona de memoria compartida y obtención del puntero*/
    recid = shmget(CLAVE, TAM, IPC_CREAT|PERMISIONS);
    mem = (char*) shmat(recid, NULL, 0);
    if(mem == (char*)-1){
        printf("ERROR GETTING POINTER\n");
        exit(EXIT_SUCCESS); 
    }
    
    /*2. Creamos el semáforo y asignamos los valores --> Pos 0 arr mutex, Pos 1 arr sync*/
    semid = semget(CLAVE, 2, PERMISIONS|IPC_CREAT);
    
    arg.val = 1; /*MUTEX*/
    if(semctl(semid,0,SETVAL,arg)== -1){
        printf("ERROR ESTABLISHING MUTEX VALUE\n");
        exit(EXIT_SUCCESS); 
    }
    
    arg.val = 0; /*SYNC*/
    if(semctl(semid,1,SETVAL,arg)== -1){
        printf("ERROR ESTABLISHING MUTEX VALUE\n");
        exit(EXIT_SUCCESS); 
    }
    
    /*3. Vamos a acceder a la zona de memoria compartida --> DOWN A MUTEX*/
    if(semop(semid, &mutex_down, 1)== -1){
        printf("Error haciendo down a MUTEX\n");
        exit(EXIT_SUCCESS); 
    }
    
    printf("INTRODUCE EL TEXTO A SER TRADUCIDO : \n");
    fgets(mem, TAM, stdin);
    mem[strlen(mem)-1] = '\0';
    printf("TEXTO INSERTADO: %s \n", mem);
    /*Ya hemos escrito --> No debemos continuar --> UP A MUTEX (SERVER HABRÁ DE ACCEDER) Y DOWN A SYNC*/
    
    if(semop(semid, &mutex_up, 1)== -1){
        printf("Error haciendo up a MUTEX\n");
        exit(EXIT_SUCCESS); 
    }
    
    if(semop(semid, &sync_down, 1)== -1){
        printf("Error haciendo down a SYNC\n");
        exit(EXIT_SUCCESS); 
    }
    
    /*Mostramos la traducción --> Volvemos a acceder a zona de memoria compartida DOWN A MUTEX*/
    if(semop(semid, &mutex_down, 1)== -1){
        printf("Error haciendo down a MUTEX\n");
        exit(EXIT_SUCCESS); 
    }
    
    printf("LA TRADUCCIÓN HECHA POR EL SERVER ES LA SIGUIENTE: %s \n", mem+256);
    
    /*UP A MUTEX*/
    if(semop(semid, &mutex_up, 1)== -1){
        printf("Error haciendo down a MUTEX\n");
        exit(EXIT_SUCCESS); 
    }
    
    /*Desligamos zona de memoria compartida y eliminamos semáforos*/
    shmdt(mem);
    semctl(semid,0,IPC_RMID,NULL);
    semctl(semid,1,IPC_RMID,NULL);

    return (EXIT_SUCCESS);
}

